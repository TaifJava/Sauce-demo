package com.myTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SauceTest extends BaseTest{

	
	public void doLogin() {
	
	driver.get("https://www.target.com");
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.getTitle();
	driver.findElement(By.id("account")).click();
	driver.findElement(By.id("accountNav-createAccount")).click();
	driver.findElement(By.name("usernamecreateaccount")).sendKeys(timeFormat + "@gmail.com");
	driver.findElement(By.id("accountNav-createAccount")).click();
	
	/*driver.findElement(By.cssSelector("input[id=user-name]")).sendKeys("standard_user");
	driver.findElement(By.cssSelector("input[id=password]")).sendKeys("secret_sauce");
	driver.findElement(By.cssSelector("input[id=login-button]")).click(); */
}
	
	@Test(priority=1)
	public void checkInventoryItemTest() {
	doLogin();
	Assert.assertTrue(driver.findElements(By.cssSelector(".inventory_item")).size() == 6);	
	}
	
	@Test(priority=2)
	public void checkAddToCartButtonTest() {
	doLogin();
	Assert.assertTrue(driver.findElements(By.xpath("//button[text()='ADD TO CART']")).size() == 6);
		
	}
	
}
